import subprocess
from utilities.Common_libraries import smtp
import time
import os

# resp = subprocess.Popen("pytest",, shell=True)
# print()
#
#
# with open("cli.txt", "w") as f:
#     process = subprocess.Popen(['pytest'],
#                                stdout=f)
#     f.close()
# # stdout, stderr = process.communicate()
# # print(process.communicate()[0])
# # with open("cli.txt","w") as f:
# #     f.write(process.communicate()[0])
# #     f.close()
# 
# time.sleep(400)
# smtp.send_report_mail()
cwd = os.getcwd()
print(cwd)