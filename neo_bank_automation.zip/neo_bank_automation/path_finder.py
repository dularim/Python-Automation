import os


# def __current_path():
#     with open("path.txt", 'w') as f:
#         f.write(repr(os.getcwd()))
#         f.close()
#     path = repr(os.getcwd())
#     return path[1:len(path) - 1]
#
#
# def __path_folder():
#     with open(f"{__current_path()}\\\path.txt", 'r') as f:
#         path = f.read()
#         f.close()
#         return path[1:len(path) - 1]


def path_folder():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    path = repr(dir_path)
    return path[1:len(path) - 1]


if __name__ == "__main__":
    path_folder()
