import logging


class Logger:

    def __init__(self, filename="automation"):
        self.logger = logging.getLogger("__name__")
        self.formater = logging.Formatter("%(asctime)s %(levelname)s:%(message)s")
        file_handler = logging.FileHandler(".//seleniumPython//automation-log" + filename + ".log", 'a')
        file_handler.setFormatter(self.formater)
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(self.formater)
        self.logger.addHandler(file_handler)
        # self.logger.addHandler(stream_handler)

    def log_critical(self,msg):
        self.logger.setLevel(logging.CRITICAL)
        self.logger.critical(msg)

    def log_error(self,msg):
        self.logger.setLevel(logging.ERROR)
        self.logger.error(msg)

    def log_warning(self,msg):
        self.logger.setLevel(logging.WARNING)
        self.logger.warning(msg)

    def log_info(self,text):
        self.logger.setLevel(logging.INFO)
        self.logger.info(text)

    def log_debug(self,text):
        self.logger.setLevel(logging.DEBUG)
        self.logger.debug(text)


if __name__ == "__main__":
    a = Logger()
    a.log_critical("tested")
    a.log_error("tested")
    a.log_warning("tested")
    a.log_info("tested")
    a.log_debug("tested")


# from path_finder import path_folder
#
# print(f"{path_folder()}\\Log")
# print(f"{path_folder()}")
# print(f"{path_folder()}")
# print(f"{path_folder()}")
# print(f"{path_folder()}")
# print(f"{path_folder()}")
