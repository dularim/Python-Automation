import configparser

config = configparser.RawConfigParser()
config.read("./Configuration/config.py")


class ReadConfig:
    @staticmethod
    def getApplicationURL():
        url = config.get('info', 'baseUrl')
        return url

    @staticmethod
    def get_username():
        username = config.get("info", "username")
        return username

    @staticmethod
    def get_password():
        password = config.get("info", "password")
        return password
