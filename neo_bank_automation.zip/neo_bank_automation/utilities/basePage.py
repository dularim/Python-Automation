import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from utilities import readProperties


class BasePage:

    def __init__(self, driver):
        self.driver = driver

    def getLocatorType(self, locatorType):
        if locatorType == "id":
            return By.ID
        elif locatorType == "name":
            return By.NAME
        elif locatorType == "xpath":
            return By.XPATH
        elif locatorType == "css":
            return By.CSS_SELECTOR
        elif locatorType == "class":
            return By.CLASS_NAME
        elif locatorType == "link":
            return By.LINK_TEXT

    def click(self, locator, locatorType):
        getType = self.getLocatorType(locatorType)
        self.driver.find_element(getType, locator).click()
        self.driver.find_element(By.ID(locator)).click()

    def sendKeys(self, locator, value):
        self.driver.find_element_by_xpath(locator).send_keys(value)

    def sleep(self, sec):
        time.sleep(sec)

    def clearValue(self, locator, locatorType):
        getType = self.getLocatorType(locatorType)
        ele = self.driver.find_element(getType, locator)
        ele.send_keys(Keys.CONTROL, "a", Keys.DELETE)

    def isDisplayed(self, locator, locatorType):
        getType = self.getLocatorType(locatorType)
        ele = self.driver.find_element(getType, locator)
        ele.is_displayed()

    # def is_visible(self, by_locator):
    #     element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator))
    #     return bool(element)
    #
    # def get_element_text(self, by_locator):
    #     element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator))
    #     return element.text
    #
    # def get_ele_text(self, by_locator):
    #     element = self.driver.find_element(*by_locator)
    #     return element.text
    #
    # def get_elements_text(self, by_locator):
    #     return self.driver.find_elements(*by_locator)
    #
    # def do_locate(self, by_locator):
    #     return self.driver.find_element_by_xpath(*by_locator)
    #
    # def do_wait_for(self, by_locator):
    #     WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator))
    #
    # def get_the_attribute(self, by_locator, attribute):
    #     WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator)).get_attribute(attribute)
    #
    # def get_screen_shot(self, screen_name):
    #     self.driver.save_screenshot(".//ScreenShots//" + screen_name + ".png")
    #
    # def do_implicit_wait(self, time=10):
    #     self.driver.implicitly_wait(time)
    #
    # def get_current_url(self):
    #     return self.driver.current_url
    #
    # def get_page_source(self):
    #     return self.driver.page_source()
    #
    # def get_title(self):
    #     return self.driver.title()
    #
    # def get_window_handle(self):
    #     return self.driver.window_handles()
    #
    # def get_current_window_handle(self):
    #     return self.driver.current_window_handle()
    #
    # def close_current_tab(self):
    #     self.driver.close()
    #
    # def switch_the_tab(self, handle):
    #     self.driver.switch_to.window(handle)
    #
    # def execute_script(self, script):
    #     self.driver.execute_script(script)
    #
    # def max_window(self):
    #     self.driver.maximize_window()
    #
    # def min_window(self):
    #     self.driver.minimize_window()
    #
    # def do_clear(self, by_locator):
    #     WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator)).clear()
    #
    # def is_enabled(self, by_locator):
    #     return WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator)).is_enabled()
    #
    # def is_selected(self, by_locator):
    #     return WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator)).is_selected()
    #
    # def do_wait_for(self, by_locator):
    #     WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator))
    #
    # def scroll_by_pixel(self, value):
    #     self.driver.execute_script(f'window.scrollBy(0, {value})')
    #
    # def scroll_by_element(self, by_locator):
    #     element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator))
    #     self.driver.execute_script("window.scrollIntoView();", element)
    #
    # def scroll_page_end(self):
    #     self.driver.execute_script("window.scrollBy(0,document.body.scrollHeight)")
    #
    # def links_on_page(self):
    #     linklist = self.driver.find_elments(By.TAG_NAME, "a")
    #     for x in linklist:
    #         print(x.get_attribute("href"))
    #
    # def link_of_element(self, text_of_link):
    #     element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located((By.LINK_TEXT, text_of_link)))
    #     print(element.get_attribute("href"))
    #
    # def images_on_page(self):
    #     imagelist = self.driver.find_elments(By.TAG_NAME, "img")
    #     for x in imagelist:
    #         print(x.get_attribute("src"))
    #
    # def dropdown(self, by_locator, value):
    #     y = Select(by_locator)
    #     y.select_by_value(value)
    #
    # def hoverover(self, by_locator):
    #     act_chains = ActionChains(self.driver)
    #     act_chains.move_to_element(by_locator).perform()
    #
    # def file_upload(self, by_locator, path):
    #     self.driver.find_element(*by_locator).send_keys(path)
    #
    # def page_back(self):
    #     self.driver.back()
    #
    # def page_forward(self):
    #     self.driver.forward()
    #
    # def page_refresh(self):
    #     self.driver.refresh()
    #
    # def drag_and_drop(self, source, target):
    #     act_chains = ActionChains(self.driver)
    #     act_chains.drag_and_drop(source, target).perform()
    #
    # def popup_accept(self):
    #     alert = self.driver.switch_to.alert
    #     alert.accept()
    #     self.driver.switch_to.default_content()
    #
    # def popup_reject(self):
    #     alert = self.driver.switch_to.alert
    #     alert.accept()
    #     self.driver.switch_to.default_content()
    #
    # def popup_enter_value(self, value):
    #     alert = self.driver.switch_to.alert
    #     alert.send_keys(value)
    #     self.driver.switch_to.default_content()
    #
    # def switch_to_frame(self, by_locator):
    #     frame_element = self.driver.find_elment(by_locator)
    #     self.driver.switch_to.frame(frame_element)
    #
    # def switch_to_default_content(self):
    #     self.driver.switch_to.default_content()
    #
    # def switch_to_parent_frame(self):
    #     self.driver.switch_to.parent_frame()
    #
    # def search(self, by_locator, text_value):
    #     search = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator))
    #     search.send_keys(text_value)
    #     search.submit()
    #
    # def tab_button(self):
    #     act_chains = ActionChains(self.driver)
    #     act_chains.key_down(Keys.TAB).perform()
    #
    # def enter_button(self):
    #     act_chains = ActionChains(self.driver)
    #     act_chains.key_down(Keys.ENTER).perform()
    #
    # def current_url_page(self):
    #     return self.driver.current_url
    #
    # def get_url(self, url):
    #     self.driver.get(url)
    #
    # def get_source_file(self, filename):
    #     file = open(".//PageSource//" + filename + ".txt", "w")
    #     file.write(self.driver.page_source)
    #     file.close()
