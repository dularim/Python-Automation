from pageFunctions.loginPage import LoginPage
import pytest


@pytest.mark.usefixtures("oneTimeSetUp")
class TestComplete:
    def test_login(self):
        self.login = LoginPage(self.driver)
        self.login.loginFunctionInvalidUserName()


