from selenium import webdriver
import pytest
from webdriver_manager.chrome import ChromeDriverManager
import configuration.config as cfg


def getWebDriverInstance(browser):
    if browser == "firefox":
        # Set fireFox driver
        driver = webdriver.Firefox()

    else:
        # Set chrome driver
        driver = webdriver.Chrome(ChromeDriverManager().install())
        driver.set_window_size(2048, 1536)

    if browser == "headless_chrome":
        options = webdriver.ChromeOptions()
        options.headless = True
        # options.add_argument("--incognito")
        driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)

    # Setting Driver Implicit Time out for An Element
    driver.implicitly_wait(10)
    # Maximize the window
    driver.maximize_window()
    # Loading browser with App URL
    driver.get(cfg.URL_config['baseUrl'])
    return driver


@pytest.fixture(scope="class")
def oneTimeSetUp(request):
    driver = getWebDriverInstance(browser="chrome")

    if request.cls is not None:
        request.cls.driver = driver

    yield driver
    driver.quit()
