from pageFunctions.loginPage import LoginPage
from pageFunctions.consentPopupPage import ConsentPopupPage
import pytest


@pytest.mark.usefixtures("oneTimeSetUp")
class TestComplete:
    def test_login(self):
        self.login = LoginPage(self.driver)
        self.login.loginFunctionInvalidUserName()
        # self.login.loginFunctionInvalidPassword()
        # self.login.loginFunctionInvalidDetails()
        # self.login.loginFunctionEmptyDetails()
        # self.login.verifyLoginFunctionPlaceholders()
        # self.login.loginFunctionWithCheckbox()
        # self.login.forgotPasswordFunction()
        # self.login.backToLoginFunction()
        self.login.loginFunctionWithValidDetails()

    def test_consent(self):
        self.consent = ConsentPopupPage(self.driver)
        self.consent.consentPopupFunction()