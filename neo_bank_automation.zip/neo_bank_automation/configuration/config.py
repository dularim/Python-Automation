URL_config = {
    "baseUrl": "https://neobankqa.validus.sg/"
    # "baseUrl": "https://docs.google.com/spreadsheets/d/10t1nzyoclOhV8uFjPn2MxaMUR-0-DVKjKIvJSuF3qXg/edit#gid=0"
}

login_credentials = {
    "username": "accountdetails@validus.sg",
    "password": "Admin123"
}
