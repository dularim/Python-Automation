from utilities.basePage import BasePage
from pageLocators.loginPage import LoginLocator
import pandas as pd

file = pd.read_csv("D:\\git\\neo_bank_automation\\testData\\testData.csv")


class LoginPage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.basePage = BasePage(self.driver)

    def loginForAccount(self):
        self.basePage.sleep(5)
        self.basePage.click(LoginLocator.login_button_forAccount_xpath, "xpath")

    def enterUsername(self, value):
        self.basePage.clearValue(LoginLocator.username_textbox_xpath, "xpath")
        self.basePage.sendKeys(LoginLocator.username_textbox_xpath, value)

    def enterPassword(self, value):
        self.basePage.clearValue(LoginLocator.password_textbox_xpath, "xpath")
        self.basePage.sendKeys(LoginLocator.password_textbox_xpath, value)

    def loginButton(self):
        self.basePage.click(LoginLocator.login_button_xpath, "xpath")
        self.basePage.sleep(5)

    def verifyUserName(self):
        self.basePage.isDisplayed(LoginLocator.username_textbox_xpath, "xpath")

    def verifyPassword(self):
        self.basePage.isDisplayed(LoginLocator.password_textbox_xpath, "xpath")

    def termsAndConditionCheckboxVerify(self):
        self.basePage.isDisplayed(LoginLocator.Terms_condition_checkbox_class, "class")

    def termsAndConditionCheckbox(self):
        self.basePage.click(LoginLocator.Terms_condition_checkbox_class, "class")

    def forgotPasswordLink(self):
        self.basePage.click(LoginLocator.forgot_password_xpath, "xpath")

    def resetPasswordButtonClick(self):
        self.basePage.click(LoginLocator.reset_password_xpath, "xpath")

    def back_to_login_link_click(self):
        self.basePage.click(LoginLocator.back_to_login_link_id, "id")

    def back_to_login_button_click(self):
        self.basePage.click(LoginLocator.back_to_login_button_xpath, "xpath")

    def usernameCharacterLimit(self):
        maxLength = LoginLocator.username_textbox_xpath.getAttribute("value")
        maxLength = maxLength.length()
        print(maxLength)

    def verifyIncorrectLoginDetails(self):
        self.basePage.isDisplayed(LoginLocator.errorMessage_login_details_xpath, "xpath")

    def verifyTermsAndConditionErrorMessage(self):
        self.basePage.isDisplayed(LoginLocator.errorMessage_terms_condition_xpath, "xpath")

    def loginFunctionWithValidDetails(self):
        self.enterUsername("accountdetails@validus.sg")
        self.enterPassword("Admin123")
        self.loginButton()

    def loginFunctionInvalidUserName(self):
        self.loginForAccount()
        self.enterUsername(file['Username'][0])
        self.enterPassword("Admin123")
        self.loginButton()
        self.verifyIncorrectLoginDetails()

    def loginFunctionInvalidPassword(self):
        self.enterUsername("accountdetails@validus.sg")
        self.enterPassword("Adm")
        self.loginButton()
        self.verifyIncorrectLoginDetails()

    def loginFunctionInvalidDetails(self):
        self.enterUsername("accountdetails@gmail.com")
        self.enterPassword("Adm")
        self.loginButton()
        self.verifyIncorrectLoginDetails()

    def loginFunctionEmptyDetails(self):
        self.enterUsername(" ")
        self.enterPassword(" ")
        self.loginButton()
        self.verifyIncorrectLoginDetails()

    def verifyLoginFunctionPlaceholders(self):
        self.verifyUserName()
        self.verifyPassword()
        self.loginButton()

    def loginFunctionWithCheckbox(self):
        self.enterUsername("accountdetails@validus.sg")
        self.enterPassword("Admin")
        self.termsAndConditionCheckbox()
        self.loginButton()
        self.verifyTermsAndConditionErrorMessage()

    def forgotPasswordFunction(self):
        self.forgotPasswordLink()
        self.enterUsername("accountdetails@validus.sg")
        self.resetPasswordButtonClick()
        self.back_to_login_button_click()

    def backToLoginFunction(self):
        self.forgotPasswordLink()
        self.back_to_login_link_click()

