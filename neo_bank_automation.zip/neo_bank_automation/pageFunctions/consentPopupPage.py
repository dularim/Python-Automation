from utilities.basePage import BasePage
from pageLocators.consentPopup import ConsentPopupLocators


class ConsentPopupPage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.basePage = BasePage(self.driver)

    def verifyConsentPopup(self):
        self.basePage.isDisplayed(ConsentPopupLocators.consent_popup_verify_xpath, "xpath")

    def clickOnConfirmButton(self):
        self.basePage.click(ConsentPopupLocators.confirm_button_id, "id")

    def clickOnCancelButton(self):
        self.basePage.click(ConsentPopupLocators.cancel_button_id, "id")

    def consentPopupFunction(self):
        consentPopup = 'Confirm'

        self.verifyConsentPopup()
        if consentPopup == 'Confirm':
            self.clickOnConfirmButton()
        else:
            self.clickOnCancelButton()
        print('consent popup selected as :', consentPopup)
        self.basePage.sleep(5)
