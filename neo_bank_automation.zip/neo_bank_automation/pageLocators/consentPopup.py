class ConsentPopupLocators:

    confirm_button_id = 'confirm-button'
    cancel_button_id = 'cancel-button'
    consent_popup_verify_xpath = '//p[contains(text(),"Please ‘Confirm’ to")]'
