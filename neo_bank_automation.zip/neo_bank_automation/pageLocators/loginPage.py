class LoginLocator:

    # Login page locators
    login_button_forAccount_xpath = '//button[text()="Login"]'
    username_textbox_xpath = '//input[@type="email"]'
    errorMessage_login_details_xpath = '//p[contains(text()," Please enter valid email address") or contains(text(),"Email or password is incorrect")]'
    errorMessage_terms_condition_xpath = '//p[contains(text(),"Please agree the Terms and Conditions")]'
    password_textbox_xpath = '//input[@type="password"]'
    login_button_xpath = '//button[text()=" Login "]'
    Terms_condition_checkbox_class = 'check-box'
    termOfUse_link_xpath = '//span[@class="small terms-conditions"]//a[1]'
    privacyPolicy_link_xpath = '//span[@class="small terms-conditions"]//a[2]'
    SME_link_xpath = '//span[@class="small terms-conditions"]//a[3]'
    investor_link_xpath = '//span[@class="small terms-conditions"]//a[4]'
    forgot_password_xpath = '//a[text()="Forgot password?"]'
    reset_password_xpath = '//button[@type="submit"]'
    back_to_login_link_id = 'loginlink'
    back_to_login_button_xpath = '//button[@type="submit"]'
